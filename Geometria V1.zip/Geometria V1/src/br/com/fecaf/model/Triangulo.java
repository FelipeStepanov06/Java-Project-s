package br.com.fecaf.model;

import java.util.Scanner;
//menu triangulo
public class Triangulo {
    private String tipo;
    private double lado1,lado2,base, area,perimetro,semiperimetro;
    private boolean is345;
    private double menorLado,ladoMaior,ladoMedio;
    Scanner scanner = new Scanner(System.in);





    //sistema de cadastro do triangulo
    public void cadastrarTriangulo(){
        System.out.println("/* Cadastrar Triangulo */");
        System.out.println("Informe lado 1: ");
        lado1 = scanner.nextDouble();
        System.out.println("Informe lado 2: ");
        lado2 = scanner.nextDouble();
        System.out.println("Informe a base");
        base = scanner.nextDouble();
        System.out.println("/****************************************/");
        System.out.println("Triangulo Cadastrado com Sucesso");
        System.out.println("/****************************************/");


    }


    public void exibir() {
        System.out.println("/*****    Exibir Triangulo   *****/");
        System.out.println("Lado 1: " + lado1);
        System.out.println("Lado 2: " + lado2);
        System.out.println("Base: " + base);
        System.out.println("Area: " + area);
        System.out.println("Perimetro: " + perimetro);
        System.out.println("Valido:" + validarTriangulo());
        System.out.println("Triangulo Retangulo: "+ validarTrianguloRetangulo());
        System.out.println("É 3-4-5: "+ is345());
        System.out.println("/**********************************/");

    }

    public boolean is345(){
        menorLado = Math.min(this.lado1,Math.min(this.lado2,this.base));
        ladoMaior = Math.max(this.lado1,Math.max(this.lado2,this.base));

        ladoMedio = (this.lado1+this.lado2+this.base)-menorLado-ladoMaior;

        if (menorLado / 3 == ladoMedio / 4 && ladoMedio / 4 == ladoMaior / 5){

            return true;
        }else{
            return false;
        }

    }

    public boolean validarTrianguloRetangulo() {
        if ((lado1 * lado1) + (lado2 * lado2) == (base * base)) {


            return true;
        } else {
            return false;
        }
    }

    public double calcularArea () {
        System.out.println("/*** Calcular Area ***/");
        semiperimetro = (lado1+lado2+base)/2;
        double resultado = semiperimetro*(semiperimetro-lado1)*(semiperimetro-lado2)*(semiperimetro-base);
        area = Math.sqrt(resultado);
        return  area;
    }

    public double calcularPerimetro () {
        System.out.println("/*** Calcular Perimetro ***/");
        perimetro = lado1 + lado2 + base;
        return perimetro;
    }



//validação do triangulo
    public boolean validarTriangulo(){
        if (lado1 + base > lado2 && lado1+lado2 >base && lado2 +base >lado1){

            return true;
        }

        return false;
    }

//definição dos tipos de triangulo
    public void definirTipo(){
        System.out.println("/*** Definir tipo ***/");

        //isosceles -> Escaleno -> Equilatero

        if (lado1 == lado2 && lado2 == base){
            System.out.println("Esse triangulo é equilatero");
            tipo = "Equilatero";
        } else if (lado1 != lado2 && lado2 !=base && base != lado1) {
            System.out.println("Esse triangulo é Escaleno");
            tipo = "Escaleno";
        } else {
            System.out.println("Esse triangulo é Isosceles");
            tipo = "Isosceles";
        }
    }

    public double getLado1() {
        return lado1;
    }

    public void setLado1(double lado1) {
        this.lado1 = lado1;
    }

    public double getLado2() {
        return lado2;
    }

    public void setLado2(double lado2) {
        this.lado2 = lado2;
    }

    public double getBase() {
        return base;
    }

    public void setBase(double base) {
        this.base = base;
    }


    public double getArea() {
        return area;
    }

    public void setArea(double area) {
        this.area = area;
    }

    public double getPerimetro() {
        return perimetro;
    }

    public void setPerimetro(double perimetro) {
        this.perimetro = perimetro;
    }

    public double getLadoMedio() {
        return ladoMedio;
    }

    public void setLadoMedio(double ladoMedio) {
        this.ladoMedio = ladoMedio;
    }

    public double getLadoMaior() {
        return ladoMaior;
    }

    public void setLadoMaior(double ladoMaior) {
        this.ladoMaior = ladoMaior;
    }

    public double getMenorLado() {
        return menorLado;
    }

    public void setMenorLado(double menorLado) {
        this.menorLado = menorLado;
    }

    public boolean isIs345() {
        return is345;
    }

    public void setIs345(boolean is345) {
        this.is345 = is345;
    }
}

