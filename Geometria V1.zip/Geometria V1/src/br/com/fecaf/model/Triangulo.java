package br.com.fecaf.model;

import java.util.Scanner;
//menu triangulo
public class Triangulo {
    private String tipo;
    private double lado1,lado2,base, altura, area;
    private double is345;
    private double menorLado,ladoMaior,ladoMedio;
    Scanner scanner = new Scanner(System.in);

    //sistema de cadastro do triangulo
    public void cadastrarTriangulo(){
        System.out.println("/* Cadastrar Triangulo */");
        System.out.println("Informe lado 1: ");
        lado1 = scanner.nextDouble();
        System.out.println("Informe lado 2: ");
        lado2 = scanner.nextDouble();
        System.out.println("Informe a base");
        base = scanner.nextDouble();
        System.out.println("/****************************************/");
        System.out.println("Triangulo Cadastrado com Sucesso");
        System.out.println("/****************************************/");



    }
    public void is345(){
        menorLado = Math.min(this.lado1,Math.min(this.lado2,this.base));
        ladoMedio = (this.lado1+this.lado2+this.base)-menorLado-ladoMaior;
        ladoMaior = Math.max(this.lado1,Math.max(this.lado2,this.base));

        if ((3*menorLado)*(3*menorLado)+(4*ladoMedio)*(4*ladoMedio) == (5*ladoMaior)*(5*ladoMaior)){
            System.out.println("É metodo 3-4-5");

        }else{
            System.out.println("Não é metodo 3-4-5");
        };

    }
    public boolean validarTrianguloRetangulo() {
        if ((lado1 * lado1) + (lado2 * lado2) == (base * base)) {

            System.out.println("É um Triângulo Retângulo");

            return true;
        } else {
            System.out.println("Não é um Triângulo Retângulo");
            return false;
        }
    }



//validação do triangulo
    public boolean validarTriangulo(){
        if (lado1 + base > lado2 && lado1+lado2 >base && lado2 +base >lado1){
            System.out.println("Triangulo Valido");

            return true;
        }
        System.out.println("Triangulo Invalido");
        return false;
    }
//definição dos tipos de triangulo
    public void definirTipo(){
        System.out.println("/*** Definir tipo ***/");

        //isosceles -> Escaleno -> Equilatero

        if (lado1 == lado2 && lado2 == base){
            System.out.println("Esse triangulo é equilatero");
            tipo = "Equilatero";
        } else if (lado1 != lado2 && lado2 !=base && base != lado1) {
            System.out.println("Esse triangulo é Escaleno");
            tipo = "Escaleno";
        } else {
            System.out.println("Esse triangulo é Isosceles");
            tipo = "Isosceles";
        }
    }

    public double getLadoMedio() {
        return ladoMedio;
    }

    public void setLadoMedio(double ladoMedio) {
        this.ladoMedio = ladoMedio;
    }

    public double getLadoMaior() {
        return ladoMaior;
    }

    public void setLadoMaior(double ladoMaior) {
        this.ladoMaior = ladoMaior;
    }

    public double getMenorLado() {
        return menorLado;
    }

    public void setMenorLado(double menorLado) {
        this.menorLado = menorLado;
    }

    public double getIs345() {
        return is345;
    }

    public void setIs345(double is345) {
        this.is345 = is345;
    }
}

